---
title: Et Ad Est
slug: et-ad-est
updated-on: '2022-04-14T19:12:22.224Z'
created-on: '2022-04-10T18:04:51.752Z'
published-on: '2022-04-14T19:12:55.979Z'
f_testimonial: >-
  The goclass cohorts are a great way to learn, and the teachers were super
  helpful!
f_cohort:
  - cms/product/learn-about-earned-media.md
  - cms/product/create-lottie-animations.md
  - cms/product/make-interactive-websites-in-webflow.md
f_avatar:
  url: >-
    https://uploads-ssl.webflow.com/630a46b33591b52c7e6df4c8/630a46b33591b5b9b06df5cf_square%20seven.jpg
  alt: null
f_company: Google
f_person-name: Cam Wontan
layout: '[testimonials].html'
tags: testimonials
---


