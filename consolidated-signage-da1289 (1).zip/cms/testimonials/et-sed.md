---
title: Et Sed
slug: et-sed
updated-on: '2022-04-14T19:12:50.413Z'
created-on: '2022-04-10T18:04:51.750Z'
published-on: '2022-04-14T19:12:55.979Z'
f_testimonial: >-
  I was online with my fellow cohort members and teachers every day, it was so
  much fun!
f_cohort:
  - cms/product/learn-about-earned-media.md
  - cms/product/make-interactive-websites-in-webflow.md
f_avatar:
  url: >-
    https://uploads-ssl.webflow.com/630a46b33591b52c7e6df4c8/630a46b33591b524516df5d0_square%20five.jpg
  alt: null
f_company: Apple
f_person-name: Faye Wilson
layout: '[testimonials].html'
tags: testimonials
---


