---
title: Et Neque
slug: et-neque
updated-on: '2022-04-14T19:12:03.318Z'
created-on: '2022-04-10T18:04:51.769Z'
published-on: '2022-04-14T19:12:55.979Z'
f_testimonial: >-
  It was a great experience, and I'm so glad I did it. I would recommend it to
  anyone who wants to learn online.
f_cohort:
  - cms/product/learn-about-earned-media.md
f_avatar:
  url: >-
    https://uploads-ssl.webflow.com/630a46b33591b52c7e6df4c8/630a46b33591b5c1026df5ce_square%20three.jpg
  alt: null
f_company: Zoom
f_person-name: Emily Sharpow
layout: '[testimonials].html'
tags: testimonials
---


