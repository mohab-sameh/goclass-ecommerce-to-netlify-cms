---
title: Autem Dolores
slug: autem-dolores
updated-on: '2022-04-14T19:11:41.608Z'
created-on: '2022-04-10T18:04:51.799Z'
published-on: '2022-04-14T19:12:55.979Z'
f_testimonial: >-
  The online format was amazing and learning in a small group was a great
  experience.
f_cohort:
  - cms/product/build-and-use-a-design-system.md
f_avatar:
  url: >-
    https://uploads-ssl.webflow.com/630a46b33591b52c7e6df4c8/630a46b33591b516cc6df5cc_square%20twelve.jpg
  alt: null
f_company: Airtable
f_person-name: Aisha Bashar
layout: '[testimonials].html'
tags: testimonials
---


