---
title: Et Sed Copy
slug: et-sed-copy
updated-on: '2022-04-14T19:10:02.290Z'
created-on: '2022-04-10T18:05:19.692Z'
published-on: '2022-04-14T19:12:55.979Z'
f_cohort:
  - cms/product/build-and-use-a-design-system.md
  - cms/product/create-lottie-animations.md
f_testimonial: >-
  It was so helpful to be able to discuss design concepts with other people who
  were also passionate about design.
f_avatar:
  url: >-
    https://uploads-ssl.webflow.com/630a46b33591b52c7e6df4c8/630a46b33591b508ff6df5cb_square%20nine.jpg
  alt: null
f_company: Spotify
f_person-name: Hannah Campton
layout: '[testimonials].html'
tags: testimonials
---


