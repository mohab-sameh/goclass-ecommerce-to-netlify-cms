---
title: Quia Delectus
slug: quia-delectus
updated-on: '2022-04-14T19:11:24.204Z'
created-on: '2022-04-10T18:04:51.774Z'
published-on: '2022-04-14T19:12:55.979Z'
f_testimonial: >-
  If you're thinking about taking an online course, I would definitely recommend
  learning with goclass!
f_cohort:
  - cms/product/build-and-use-a-design-system.md
  - cms/product/create-lottie-animations.md
  - cms/product/make-interactive-websites-in-webflow.md
f_avatar:
  url: >-
    https://uploads-ssl.webflow.com/630a46b33591b52c7e6df4c8/630a46b33591b55d616df5cd_square%20two.jpg
  alt: null
f_company: Webflow
f_person-name: Yemi Musa
layout: '[testimonials].html'
tags: testimonials
---


