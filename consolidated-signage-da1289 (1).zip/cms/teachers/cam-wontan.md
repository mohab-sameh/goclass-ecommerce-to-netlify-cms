---
title: Cam Wontan
slug: cam-wontan
updated-on: '2022-04-18T22:28:22.504Z'
created-on: '2022-04-07T23:04:39.627Z'
published-on: '2022-04-18T22:31:28.959Z'
f_portrait-image:
  url: >-
    https://uploads-ssl.webflow.com/630a46b33591b52c7e6df4c8/630a46b33591b57c396df5d4_face-nine%202.jpg
  alt: null
f_my-story-image:
  url: >-
    https://uploads-ssl.webflow.com/630a46b33591b52c7e6df4c8/630a46b33591b571e56df5ae_cohort-sixteen%201.jpg
  alt: null
f_avatar-image:
  url: >-
    https://uploads-ssl.webflow.com/630a46b33591b52c7e6df4c8/630a46b33591b5b9b06df5cf_square%20seven.jpg
  alt: null
f_quote: >-
  "With so much of our lives happening online, it's important to have a website
  that presents our best selves to the world."
f_past-position-date-one: 2019-2021
f_past-position-date-three: 2017-2018
f_past-position-date-two: 2018-2019
f_past-position-one: Airtable, Junior Designer
f_past-position-three: Spotify, Senior Designer
f_past-position-two: Webflow, Brand Designer
f_specialty: Design Teacher
f_short-description: >-
  Cam is really good at designing webflow cloneable websites, and she enjoys
  sharing her work with the community.
layout: '[teachers].html'
tags: teachers
---

Cam loved growing up in the city. Even though she was born and raised in New York City, she managed to find time to travel the world and teach design. She also loved surfing, and whenever she could fit it in, she would head to the beach for a few waves. Cam was really good at designing webflow cloneable websites, and she enjoyed sharing her work with the community.
