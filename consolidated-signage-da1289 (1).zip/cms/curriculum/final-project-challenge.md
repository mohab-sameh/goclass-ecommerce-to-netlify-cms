---
title: Final project challenge
slug: final-project-challenge
updated-on: '2022-04-12T19:07:38.088Z'
created-on: '2022-04-10T02:57:10.765Z'
published-on: '2022-04-12T19:08:09.222Z'
f_cohort:
  - cms/product/build-and-use-a-design-system.md
  - cms/product/make-interactive-websites-in-webflow.md
  - cms/product/create-lottie-animations.md
  - cms/product/learn-about-earned-media.md
f_week: Week eight
f_order-number: 8
f_description: >-
  Think you're a web design whiz? Prove it! With this class, you can take on the
  biggest design challenges and see how well you do. Present your work to a team
  of credible designers and see how you compare. You'll learn new techniques and
  get valuable feedback in the process.
layout: '[curriculum].html'
tags: curriculum
---


