---
title: Group visual challenge
slug: group-visual-challenge
updated-on: '2022-04-12T19:07:52.676Z'
created-on: '2022-04-10T02:57:11.720Z'
published-on: '2022-04-12T19:08:09.222Z'
f_cohort:
  - cms/product/build-and-use-a-design-system.md
  - cms/product/make-interactive-websites-in-webflow.md
  - cms/product/create-lottie-animations.md
  - cms/product/learn-about-earned-media.md
f_week: Week five
f_order-number: 5
f_description: >-
  This is the perfect class for those passionate designers who want to
  collaborate with a full team and see their work come to life. You'll learn how
  to communicate your vision, present your work persuasively, and get feedback
  from experienced professionals.
layout: '[curriculum].html'
tags: curriculum
---


