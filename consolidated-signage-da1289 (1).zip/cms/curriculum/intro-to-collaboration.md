---
title: Intro to collaboration
slug: intro-to-collaboration
updated-on: '2022-04-12T19:07:57.299Z'
created-on: '2022-04-10T02:57:11.764Z'
published-on: '2022-04-12T19:08:09.222Z'
f_cohort:
  - cms/product/build-and-use-a-design-system.md
  - cms/product/make-interactive-websites-in-webflow.md
  - cms/product/create-lottie-animations.md
  - cms/product/learn-about-earned-media.md
f_week: Week four
f_order-number: 4
f_description: >-
  In this class, you'll learn how to collaborate on new projects with other
  designers effectively. You'll be able to present your work to a team of
  credible designers and classmates in no time at all!
layout: '[curriculum].html'
tags: curriculum
---


