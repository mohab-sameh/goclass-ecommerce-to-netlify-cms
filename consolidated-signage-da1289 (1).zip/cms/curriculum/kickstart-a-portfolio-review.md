---
title: Kickstart a portfolio review
slug: kickstart-a-portfolio-review
updated-on: '2022-04-12T19:07:43.100Z'
created-on: '2022-04-10T02:57:11.171Z'
published-on: '2022-04-12T19:08:09.222Z'
f_cohort:
  - cms/product/build-and-use-a-design-system.md
  - cms/product/make-interactive-websites-in-webflow.md
  - cms/product/create-lottie-animations.md
  - cms/product/learn-about-earned-media.md
f_week: Week seven
f_order-number: 7
f_description: >-
  In this class, we provide expert reviews of your work, so you can get feedback
  from some of the best in the industry. And if you're presenting your work to a
  group, our team of credible designers can give you the support you need to
  make a great impression. After this class, you'll have everything you need to
  succeed.
layout: '[curriculum].html'
tags: curriculum
---


