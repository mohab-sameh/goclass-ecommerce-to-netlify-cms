---
title: Build a basic layout
slug: build-a-basic-layout
updated-on: '2022-04-12T19:08:04.885Z'
created-on: '2022-04-10T02:57:12.612Z'
published-on: '2022-04-12T19:08:09.222Z'
f_cohort:
  - cms/product/build-and-use-a-design-system.md
  - cms/product/create-lottie-animations.md
  - cms/product/learn-about-earned-media.md
  - cms/product/make-interactive-websites-in-webflow.md
f_week: Week two
f_order-number: 2
f_description: >-
  Think you have what it takes to design the next big website? Prove it! With
  this class, you can learn how to create beautiful websites with your
  classmates – and present your work to a team of credible designers.
layout: '[curriculum].html'
tags: curriculum
---


